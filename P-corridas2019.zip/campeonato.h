
#ifndef CAMPEONATO_H
#define CAMPEONATO_H


typedef struct pilcam Cam, *pCam;

struct pilcam{

    int piloto;
    int nCorridas;
    int pontos;

    pCam prox;
};


//função docampeonato
int campeonatomenu(psS saveS);


#endif